﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GettingDressed
{
    public class Response
    {
        public Dictionary<string, string> Dresses { get; set; }
        public string TemperatureType { get; set; }
    }
    
}