﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GettingDressed
{
    public class DressManager
    {
        #region Common Variables

        Dictionary<DressDescription, string> DresstoWear;
        Dictionary<int, DressDescription> MappedCommands;
        Response response;
        #endregion

        #region Constructor
        public DressManager()
        {
            DresstoWear = new Dictionary<DressDescription, string>();
            MappedCommands = new Dictionary<int, DressDescription>();
            response = new Response();
            response.Dresses = new Dictionary<string, string>();
        }

        #endregion

        #region Process Response
        public Response ProcessResponse(Request request)
        {
           
            try
            {
                DresstoWear = GetData(request.Temperature);
                var AllDressCommands = (DressDescription[])Enum.GetValues(typeof(DressDescription));

                #region •	If an invalid command is issued, respond with “fail” and stop processing commands
                if (!ValidationManager.ValidateRequest(request))
                {
                    response.Dresses.Add(DressUtility.PJ, DressUtility.Failstatus);
                    return response;
                }
                #endregion
                else
                {
                    foreach (int comm in request.Command)
                    {
                        if (MappedCommands.ContainsKey(comm) && DresstoWear.ContainsKey(MappedCommands[comm]))
                        {
                            #region •	Only 1 piece of each type of clothing may be put on
                            if (ValidationManager.ValidateResponse(response))
                            {
                                response.Dresses.Add(MappedCommands[comm].ToString(), DresstoWear.First(x => x.Key == MappedCommands[comm]).Value);
                            }
                            else
                            {
                                response.Dresses.Add(DressUtility.PJ, DressUtility.Failstatus);
                            }
                            #endregion
                        }
                    }

                }
                if (ValidationManager.ValidateAllRules(response))
                {
                    if (!response.Dresses.Any(x => x.Value.ToUpper() == DressUtility.Failstatus.ToUpper()))
                    {
                        #region •	You cannot leave the house until all items of clothing are on
                        if ((request.Command.Count() - 1) != DresstoWear.Count(x => x.Value != DressUtility.Failstatus))
                        {
                            response.Dresses.Add(DressUtility.PJ, DressUtility.Failstatus);
                        }
                        #endregion
                        else
                        {
                            response.Dresses.Add(DressDescription.Leavehouse.ToString(), DressDescription.Leavehouse.ToString());
                        }
                    }
                    //else
                    //{
                    //    response.Dresses.Add(DressUtility.PJ, DressUtility.Failstatus);
                    //}
                    return response;
                }
                //Default Fail Condition
                response.Dresses.Add(DressUtility.PJ, DressUtility.Failstatus);
            }
            catch (Exception ex)
            {
                //log exception
                response.Dresses.Add(DressUtility.PJ, DressUtility.Failstatus);
            }
            return response;
        }

        #endregion

        #region Get data 
        /// This would basically get data from either backend or service in real time Project 
        public Dictionary<DressDescription, string> GetData(TemperatureType temperatureType)
        {
            #region Get all Available Commands
            MappedCommands.Add(8, DressDescription.Takeoffpajamas);
            MappedCommands.Add(6, DressDescription.Putonpants);
            MappedCommands.Add(4, DressDescription.Putonshirt);
            MappedCommands.Add(3, DressDescription.Putonsocks);
            MappedCommands.Add(1, DressDescription.Putonfootwear);
            MappedCommands.Add(2, DressDescription.Putonheadwear);
            MappedCommands.Add(5, DressDescription.Putonjacket);
            MappedCommands.Add(7, DressDescription.Leavehouse);
            #endregion

            #region Always TakeoffPajamas First
            DresstoWear.Add(DressDescription.Takeoffpajamas, DressUtility.RemovingPJs);
            #endregion

            #region Get All dresses as per Temperature
            switch (temperatureType)
            {
                case TemperatureType.COLD:
                    DresstoWear.Add(DressDescription.Putonfootwear, DressUtility.Boots);
                    DresstoWear.Add(DressDescription.Putonheadwear, DressUtility.Hats);
                    DresstoWear.Add(DressDescription.Putonsocks, DressUtility.Socks);
                    DresstoWear.Add(DressDescription.Putonshirt, DressUtility.Shirt);
                    DresstoWear.Add(DressDescription.Putonjacket, DressUtility.Jacket);
                    DresstoWear.Add(DressDescription.Putonpants, DressUtility.Pants);
                    break;
                case TemperatureType.HOT:
                    DresstoWear.Add(DressDescription.Putonfootwear, DressUtility.Sandals);
                    DresstoWear.Add(DressDescription.Putonheadwear, DressUtility.Sunglasses);
                    DresstoWear.Add(DressDescription.Putonsocks, DressUtility.Failstatus);
                    DresstoWear.Add(DressDescription.Putonshirt, DressUtility.Shirt);
                    DresstoWear.Add(DressDescription.Putonjacket, DressUtility.Failstatus);
                    DresstoWear.Add(DressDescription.Putonpants, DressUtility.Shorts);
                    break;
                default:
                    DresstoWear.Add(DressDescription.Putonpants, DressUtility.PJ);
                    break;
            }
            #endregion

            return DresstoWear;
        }

        #endregion

    }
}