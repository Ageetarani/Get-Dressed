﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GettingDressed
{
    public static class ValidationManager
    {
        public static bool ValidateRequest(Request request)
        {
            try
            {
                if (request == null || request.Command == null)
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                //Log Exception
                return false;
            }
            return true;
        }
        public static bool ValidateResponse(Response response)
        {
            try
            {
                if (response != null && response.Dresses != null && response.Dresses.Count > 0)
                {
                    #region Only 1 piece of each type of clothing may be put on
                    return response.Dresses.Count() == response.Dresses.Distinct().Count();
                    #endregion
                }
            }
            catch (Exception ex)
            {
                return false;
            }
            return true;
        }
        public static bool ValidateAllRules(Response response)
        {
            try
            {
                #region All Footwear must go After Socks
                if (

                    response.Dresses.Any(x => x.Key == DressDescription.Putonfootwear.ToString()) &&
                     response.Dresses.Any(x => x.Key == DressDescription.Putonsocks.ToString()) &&
                    (response.Dresses.Keys.ToList().IndexOf(response.Dresses.First(x => x.Key == DressDescription.Putonfootwear.ToString()).Key) <
                    response.Dresses.Keys.ToList().IndexOf(response.Dresses.First(x => x.Key == DressDescription.Putonsocks.ToString()).Key))
                    )
                {
                    return false;
                }
                #endregion

                #region All Footwear must go After Pant
                else if (
                    //Rule 1 : Hats should always go after Shirt
                    response.Dresses.Any(x => x.Key == DressDescription.Putonfootwear.ToString()) &&
                     response.Dresses.Any(x => x.Key == DressDescription.Putonpants.ToString()) &&
                    (response.Dresses.Keys.ToList().IndexOf(response.Dresses.First(x => x.Key == DressDescription.Putonfootwear.ToString()).Key) <
                    response.Dresses.Keys.ToList().IndexOf(response.Dresses.First(x => x.Key == DressDescription.Putonpants.ToString()).Key))
                    )
                {
                    return false;
                }
                #endregion

                #region All Headwear must go After Shirt
                else if (
                    //Rule 1 : Hats should always go after Shirt
                    response.Dresses.Any(x => x.Key == DressDescription.Putonheadwear.ToString()) &&
                     response.Dresses.Any(x => x.Key == DressDescription.Putonshirt.ToString()) &&
                    (response.Dresses.Keys.ToList().IndexOf(response.Dresses.First(x => x.Key == DressDescription.Putonheadwear.ToString()).Key) <
                    response.Dresses.Keys.ToList().IndexOf(response.Dresses.First(x => x.Key == DressDescription.Putonshirt.ToString()).Key))
                    )
                {
                    return false;
                }
                #endregion

                #region Jacket must go After Shirt
                else if (
                    //Rule 1 : Hats should always go after Shirt
                    response.Dresses.Any(x => x.Key == DressDescription.Putonjacket.ToString()) &&
                     response.Dresses.Any(x => x.Key == DressDescription.Putonshirt.ToString()) &&
                    (response.Dresses.Keys.ToList().IndexOf(response.Dresses.First(x => x.Key == DressDescription.Putonjacket.ToString()).Key) <
                    response.Dresses.Keys.ToList().IndexOf(response.Dresses.First(x => x.Key == DressDescription.Putonshirt.ToString()).Key))
                    )
                {
                    return false;
                }
                #endregion

            }
            catch (Exception ex)
            {
                return false;
            }
            return true;
        }

    }
}