﻿using GettingDressed;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GetDressed
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                #region Intialize Request

                Request request = new Request();
                request.Command = new List<int>();

                #endregion

                #region Hardcoded Request ideally should come from front end

                //Uncomment One of the below Requests to see desired Output.If want to check a new one,please add a new Request

                #region Request1
                request.Command.Add(8);
                request.Command.Add(6);
                request.Command.Add(3);
                request.Command.Add(4);
                request.Command.Add(2);
                request.Command.Add(5);
                request.Command.Add(1);
                request.Command.Add(7);
                request.Temperature = TemperatureType.COLD;
                #endregion

                #region Request 2 
                //request.Command.Add(8);
                //request.Command.Add(6);
                //request.Command.Add(4);
                //request.Command.Add(2);
                //request.Command.Add(1);
                //request.Command.Add(7);
                //request.Temperature = TemperatureType.HOT;
                #endregion

                #region Request 3
                //request.Command.Add(8);
                //request.Command.Add(6);
                //request.Command.Add(6);
                //request.Temperature = TemperatureType.HOT;
                #endregion

                #region Request 4
                //request.Command.Add(8);
                //request.Command.Add(6);
                //request.Command.Add(3);
                //request.Temperature = TemperatureType.HOT;
                #endregion

                #region Request 5
                //request.Command.Add(8);
                //request.Command.Add(6);
                //request.Command.Add(3);
                //request.Command.Add(4);
                //request.Command.Add(2);
                //request.Command.Add(5);
                //request.Command.Add(7);
                //request.Temperature = TemperatureType.COLD;
                #endregion

                #region Request 4
                //request.Command.Add(6);
                //request.Temperature = TemperatureType.COLD;
                #endregion

                #endregion

                #region Process Response

                Response response =GetDressedResponse(request);

                #endregion

                #region Display result
                Console.WriteLine("Your Request :" + response.TemperatureType + " Tempreture : ");
                Console.WriteLine(request.Temperature);
                foreach (int comm in request.Command)
                {
                    Console.WriteLine(comm);
                }

                Console.WriteLine("Your dress for " +response.TemperatureType + " Tempreture : ");
                foreach(string key in response.Dresses.Keys)
                {
                    Console.WriteLine(response.Dresses[key]);
                }
                Console.ReadLine();

                #endregion
            }
            catch (Exception ex)
            {
                //log exception
                Console.WriteLine(DressUtility.Failstatus);
                Console.ReadLine();
            }
        }
      
        #region Get Response
        static Response GetDressedResponse(Request request)
        {
            DressManager dressManager;
            Response response;
            response = new Response();
            response.Dresses = new Dictionary<string, string>();
            dressManager = new DressManager();
            try
            {
                response = dressManager.ProcessResponse(request);
                response.TemperatureType = request.Temperature.ToString();
            }
            catch (Exception ex)
            {
                //log exception
                response.Dresses.Add(DressUtility.PJ, DressUtility.Failstatus);
            }
            return response;
        }
       
        #endregion
    }
}
