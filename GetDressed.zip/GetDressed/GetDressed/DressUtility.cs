﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GettingDressed
{
    public static class DressUtility
    {
        public static readonly string Failstatus = "Fail";

        #region Dress Options
        public static readonly string Boots = "boots";
        public static readonly string Hats = "hats";
        public static readonly string Socks = "socks";
        public static readonly string Shirt = "shirt";
        public static readonly string Jacket = "jacket";
        public static readonly string Pants = "pants";
       
        public static readonly string Sandals = "Sandals";
        public static readonly string Sunglasses = "sunglasses";
        public static readonly string Shorts = "shorts";

        public static readonly string PJ = "PJ";
        public static readonly string RemovingPJs = "Removing PJs";
        #endregion
    }

    public enum TemperatureType
    {
        HOT,
        COLD
    }
    public enum DressDescription
    {
        Takeoffpajamas = 1,
        Putonpants = 2,
        Putonshirt = 3,
        Putonsocks = 4,
        Putonfootwear = 5,
        Putonheadwear = 6,
        Putonjacket = 7,
        Leavehouse = 8
    }

}